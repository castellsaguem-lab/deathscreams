package com.example.deathscreams;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/**
 * Todos los eventos de sonido del mod. Los nombres coinciden con sounds.json.
 * Los de bandit/soldier se pueden usar en CustomNPCs escribiendo, por ejemplo,
 * "deathscreams:bandit.idle" en el campo de sonido del NPC, o con /playsound.
 */
public final class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, DeathScreams.MODID);

    // Muertes (cada evento elige al azar entre sus 10 variaciones)
    public static final RegistryObject<SoundEvent> DEATH         = reg("death");
    public static final RegistryObject<SoundEvent> DEATH_DISTANT = reg("death_distant");

    // Bandit
    public static final RegistryObject<SoundEvent> BANDIT_AGGRESSIVEINV = reg("bandit.aggressiveinv");
    public static final RegistryObject<SoundEvent> BANDIT_FIRE          = reg("bandit.fire");
    public static final RegistryObject<SoundEvent> BANDIT_HEARD         = reg("bandit.heard");
    public static final RegistryObject<SoundEvent> BANDIT_IDLE          = reg("bandit.idle");

    // Soldier
    public static final RegistryObject<SoundEvent> SOLDIER_HEARD = reg("soldier.heard");
    public static final RegistryObject<SoundEvent> SOLDIER_IDLE  = reg("soldier.idle");

    private static RegistryObject<SoundEvent> reg(String name) {
        return SOUNDS.register(name, () ->
                SoundEvent.createVariableRangeEvent(new ResourceLocation(DeathScreams.MODID, name)));
    }

    private ModSounds() {}
}
