package com.example.deathscreams;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Servidor -> cliente: "reproduce un grito de muerte (cercano o distante)". */
public class DeathScreamPacket {
    private final boolean distant;

    public DeathScreamPacket(boolean distant) {
        this.distant = distant;
    }

    public static void encode(DeathScreamPacket msg, FriendlyByteBuf buf) {
        buf.writeBoolean(msg.distant);
    }

    public static DeathScreamPacket decode(FriendlyByteBuf buf) {
        return new DeathScreamPacket(buf.readBoolean());
    }

    public static void handle(DeathScreamPacket msg, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() ->
                DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientSounds.playDeathScream(msg.distant)));
        ctx.get().setPacketHandled(true);
    }
}
