package com.example.deathscreams;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.Set;

@Mod.EventBusSubscriber(modid = DeathScreams.MODID)
public class DeathScreamHandler {

    /** Hasta esta distancia se oye el grito normal (death1..death10). */
    public static final double NEAR_DISTANCE = 24.0D;
    /** Hasta esta distancia se oye el grito "distant" (death1_distant..death10_distant). Mas alla, nada. */
    public static final double MAX_DISTANCE = 64.0D;
    /** Volumen constante (0.0 - 1.0). */
    public static final float VOLUME = 1.0F;

    /** ID de entidad del jugador. */
    private static final ResourceLocation PLAYER_ID = new ResourceLocation("minecraft", "player");

    /** IDs de entidad de los NPCs de CustomNPCs (todos los tipos que existen en el mod). */
    private static final Set<ResourceLocation> NPC_IDS = Set.of(
            new ResourceLocation("customnpcs", "customnpc"),
            new ResourceLocation("customnpcs", "customnpc64x32"),
            new ResourceLocation("customnpcs", "customnpcalex"),
            new ResourceLocation("customnpcs", "customnpcclassic"),
            new ResourceLocation("customnpcs", "npcpony"),
            new ResourceLocation("customnpcs", "npccrystal"),
            new ResourceLocation("customnpcs", "npcslime"),
            new ResourceLocation("customnpcs", "npcdragon"),
            new ResourceLocation("customnpcs", "npcgolem"));

    private static final String NPC_BASE_CLASS = "noppes.npcs.entity.EntityNPCInterface";

    // LOWEST + no recibir cancelados: si otro mod cancela la muerte (totem, etc.), no suena.
    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onLivingDeath(LivingDeathEvent event) {
        LivingEntity dead = event.getEntity();
        if (dead.level().isClientSide() || !(dead.level() instanceof ServerLevel level)) return;
        if (!shouldScream(dead)) return;

        double nearSq = NEAR_DISTANCE * NEAR_DISTANCE;
        double maxSq = MAX_DISTANCE * MAX_DISTANCE;

        for (ServerPlayer listener : level.players()) {
            double distSq = listener.distanceToSqr(dead);
            if (distSq > maxSq) continue;
            boolean distant = distSq >= nearSq;
            ModNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> listener), new DeathScreamPacket(distant));
        }
    }

    private static boolean shouldScream(LivingEntity entity) {
        ResourceLocation id = ForgeRegistries.ENTITY_TYPES.getKey(entity.getType());
        if (id != null) {
            if (id.equals(PLAYER_ID) || NPC_IDS.contains(id)) return true;
        }
        // Respaldo: cualquier subclase de EntityNPCInterface (por si otro addon registra otro tipo de NPC).
        return isCustomNpcClass(entity);
    }

    /** Detecta NPCs de CustomNPCs por nombre de clase, sin necesitar el jar para compilar. */
    private static boolean isCustomNpcClass(LivingEntity entity) {
        for (Class<?> c = entity.getClass(); c != null; c = c.getSuperclass()) {
            if (c.getName().equals(NPC_BASE_CLASS)) return true;
        }
        return false;
    }
}
