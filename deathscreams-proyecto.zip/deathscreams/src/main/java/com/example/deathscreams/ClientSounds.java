package com.example.deathscreams;

import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;

/** Solo se carga en el cliente. */
public final class ClientSounds {

    public static void playDeathScream(boolean distant) {
        SoundEvent event = distant ? ModSounds.DEATH_DISTANT.get() : ModSounds.DEATH.get();

        // Attenuation.NONE + relative=true => volumen constante, SIN perdida de fuerza con la distancia.
        // La eleccion cerca/lejos ya la hizo el servidor segun los 24 bloques.
        Minecraft.getInstance().getSoundManager().play(new SimpleSoundInstance(
                event.getLocation(),
                SoundSource.PLAYERS,
                DeathScreamHandler.VOLUME,
                1.0F,
                RandomSource.create(),
                false,
                0,
                SoundInstance.Attenuation.NONE,
                0.0D, 0.0D, 0.0D,
                true));
    }

    private ClientSounds() {}
}
