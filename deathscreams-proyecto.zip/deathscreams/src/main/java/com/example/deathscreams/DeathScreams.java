package com.example.deathscreams;

import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(DeathScreams.MODID)
public class DeathScreams {
    public static final String MODID = "deathscreams";

    public DeathScreams() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        ModSounds.SOUNDS.register(modBus);
        ModNetwork.register();
    }
}
